Realistic Deferred — Java 1.20.1 resource pack
================================================
Real CC0 (AmbientCG) photo textures for common blocks + ores + animated lava,
with LabPBR _n (normal/height) and _s (smoothness/metal/emission) maps, plus
waving grass/flowers/saplings/wheat (frame animation).

INSTALL
1. Put this .zip in  .minecraft/resourcepacks/  and enable it in
   Options > Resource Packs.

FOR THE REALISTIC LOOK (lighting, water, reflections, bloom, real waving):
   Java needs a GLSL shaderpack — the Bedrock 'Vibrant Visuals' shader does NOT
   port. Install:
     - Fabric 1.20.1 + Sodium + Iris  (or OptiFine)
     - A LabPBR shaderpack, e.g. Complementary Reimagined, Complementary
       Shaders, or BSL  (enable its PBR / SpecularMap + NormalMap option)
   Then enable this resource pack ABOVE others. The _n/_s maps above feed the
   shaderpack's PBR so blocks get depth, reflectivity and lava glow.

Texture credit: AmbientCG (CC0). Plant/lava animation derived from vanilla art.
